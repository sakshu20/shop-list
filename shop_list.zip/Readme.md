shop list

- frontend folder and shop_list folder need to node model
- yarn add packge.json
- above command enter for node model and install
- than go to folder shop_list
- and enter command
- yarn start
